<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

$nik       = $_POST['nik_anak'];
$nama      = $_POST['nama_anak'];
$tgl_lahir = $_POST['tgl_lahir'];
$ibu       = $_POST['nama_ibu'];
$ayah      = $_POST['nama_ayah'];
$alamat    = $_POST['alamat'];

$query = "INSERT INTO data_anak (nik_anak, nama_anak, tgl_lahir, nama_ibu, nama_ayah, alamat)
          VALUES (?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $query);

if (!$stmt) {
  die("Prepare failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ssssss", $nik, $nama, $tgl_lahir, $ibu, $ayah, $alamat);
$execute = mysqli_stmt_execute($stmt);

if ($execute) {
  header("Location: data_anak_admin.php");
  exit;
} else {
  die("Gagal menyimpan data: " . mysqli_error($conn));
}
