<?php
session_start();

$is_logged_in = isset($_SESSION['user_id']) && $_SESSION['role'] === 'pengguna';
$nama_pengguna = $is_logged_in ? $_SESSION['nama'] : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pengguna | Posyandu Bina Cita</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <style>
        body { font-family: 'Poppins', sans-serif; }
        .navbar-blur {
            backdrop-filter: blur(12px);
            background-color: rgba(255, 255, 255, 0.75);
        }
        .menu-card {
            transition: all 0.3s ease;
            display: flex; /* Menggunakan flexbox untuk konten di dalam kartu */
            flex-direction: column; /* Tata letak vertikal */
            justify-content: center; /* Pusatkan konten secara vertikal */
            align-items: center; /* Pusatkan konten secara horizontal */
            min-height: 180px; /* Tambahkan tinggi minimum agar lebih seragam */
        }
        .menu-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }

        /* Custom styling for Swiper pagination dots (optional) */
        .swiper-pagination-bullet-active {
            background-color: #10B981 !important; /* Green-500 */
        }

        /* Animations */
        @keyframes fadeInUptoTop {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .animate-fade-in-up {
            animation: fadeInUptoTop 0.8s ease-out forwards;
            opacity: 0; /* Awalnya sembunyikan */
        }
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
    </style>
</head>
<body class="bg-green-50 text-gray-800">

    <header class="fixed top-0 left-0 right-0 z-50 navbar-blur shadow-md">
        <div class="flex justify-between items-center px-4 sm:px-8 py-3">
            <div class="flex items-center gap-3">
                <img src="https://i.imgur.com/9rjiL5N.jpg" alt="Logo Posyandu" class="bg-transparent w-12 h-12 rounded-full object-cover border-2 border-green-600 shadow-sm" />
                <span class="text-xl font-bold text-green-800">Posyandu Bina Cita</span>
            </div>
            <?php if ($is_logged_in): ?>
                <div class="text-sm sm:text-base text-green-800 font-semibold flex items-center">
                    <i class="fas fa-hand-sparkles text-yellow-500 mr-2"></i> Selamat datang, <span class="font-bold ml-1 mr-4"><?= htmlspecialchars($nama_pengguna) ?></span>
                    <a href="logout.php" class="bg-red-500 text-white px-4 py-2 rounded-full hover:bg-red-600 transition duration-300 ease-in-out transform hover:scale-105 flex items-center text-sm">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            <?php else: ?>
                <a href="login_pengguna.php?redirect=indext_coba.php" class="bg-green-600 text-white px-5 py-2 rounded-full hover:bg-green-700 transition duration-300 ease-in-out transform hover:scale-105 flex items-center text-sm">
                    <i class="fas fa-sign-in-alt mr-2"></i> Login
                </a>
            <?php endif; ?>
        </div>
    </header>

    <section class="pt-16">
        <div class="swiper-container h-[400px] w-full rounded-b-lg shadow-xl overflow-hidden">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="https://i.imgur.com/tLmVvvy.jpg" class="w-full h-full object-cover object-center" alt="Anak-anak Sehat 1" />
                    <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center p-4">
                        <h2 class="text-white text-3xl sm:text-5xl font-extrabold text-center drop-shadow-lg leading-tight">
                            Mewujudkan Generasi Sehat & Cerdas
                        </h2>
                    </div>
                </div>
                <div class="swiper-slide">
                    <img src="https://imgur.com/96UKEBT.jpg" class="w-full h-full object-cover object-center" alt="Anak-anak Sehat 2" />
                    <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center p-4">
                        <h2 class="text-white text-3xl sm:text-5xl font-extrabold text-center drop-shadow-lg leading-tight">
                            Imunisasi Lengkap untuk Perlindungan Optimal
                        </h2>
                    </div>
                </div>
                <div class="swiper-slide">
                    <img src="https://imgur.com/V9famHy.jpg" class="w-full h-full object-cover object-center" alt="Anak-anak Sehat 3" />
                    <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center p-4">
                        <h2 class="text-white text-3xl sm:text-5xl font-extrabold text-center drop-shadow-lg leading-tight">
                            Pantau Tumbuh Kembang Buah Hati Anda
                        </h2>
                    </div>
                </div>
                <div class="swiper-slide">
                    <img src="image_44ef54.jpg" class="w-full h-full object-cover object-center" alt="Posyandu Kegiatan 4">
                    <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center p-4">
                        <h2 class="text-white text-3xl sm:text-5xl font-extrabold text-center drop-shadow-lg leading-tight">
                            Bersama Posyandu, Anak Sehat Keluarga Bahagia
                        </h2>
                    </div>
                </div>
            </div>

            <div class="swiper-pagination"></div>

        </div>
    </section>

    <section class="text-center my-16 px-4">
        <h2 class="text-3xl sm:text-5xl font-extrabold text-green-800 mb-4 animate-fade-in-up">Selamat Datang di Sistem Informasi Posyandu</h2>
        <p class="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto animate-fade-in-up delay-100">
            Platform terpadu untuk memudahkan orang tua balita dalam mengakses informasi dan layanan Posyandu Bina Cita.
        </p>
    </section>

    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 px-6 max-w-6xl mx-auto mb-20">
        <a href="<?= $is_logged_in ? 'data_anak_pengguna.php' : 'login_pengguna.php?redirect=data_anak_pengguna.php' ?>" class="menu-card bg-white p-10 rounded-2xl shadow-xl text-center text-green-700 font-semibold text-xl border border-green-200">
            <i class="fas fa-child text-4xl mb-4 text-green-600"></i><br>Data Anak & Orang Tua
        </a>
        <a href="<?= $is_logged_in ? 'imunisasi.php' : 'login_pengguna.php?redirect=imunisasi.php' ?>" class="menu-card bg-white p-10 rounded-2xl shadow-xl text-center text-green-700 font-semibold text-xl border border-green-200">
            <i class="fas fa-syringe text-4xl mb-4 text-green-600"></i><br>Imunisasi
        </a>
        <a href="<?= $is_logged_in ? 'jadwal_pengguna.php' : 'login_pengguna.php?redirect=jadwal_pengguna.php' ?>" class="menu-card bg-white p-10 rounded-2xl shadow-xl text-center text-green-700 font-semibold text-xl border border-green-200">
            <i class="fas fa-calendar-alt text-4xl mb-4 text-green-600"></i><br>Jadwal Posyandu
        </a>
        <a href="<?= $is_logged_in ? 'edukasi_ibu.php' : 'login_pengguna.php?redirect=edukasi_ibu.php' ?>" class="menu-card bg-white p-10 rounded-2xl shadow-xl text-center text-green-700 font-semibold text-xl border border-green-200">
            <i class="fas fa-book-reader text-4xl mb-4 text-green-600"></i><br>Edukasi Ibu
        </a>
    </section>

    <footer class="bg-white border-t border-green-200 py-8">
        <div class="text-center text-sm text-gray-600 mb-4">
            &copy; 2025 Posyandu Bina Cita. Semua Hak Dilindungi.
        </div>
        <div class="flex justify-center gap-6 mt-2">
            <a href="https://facebook.com" target="_blank" class="text-gray-500 hover:text-blue-600 transform hover:scale-110 transition duration-300">
                <i class="fab fa-facebook-f text-3xl"></i>
            </a>
            <a href="https://instagram.com" target="_blank" class="text-gray-500 hover:text-pink-500 transform hover:scale-110 transition duration-300">
                <i class="fab fa-instagram text-3xl"></i>
            </a>
            <a href="https://wa.me/6281234567890" target="_blank" class="text-gray-500 hover:text-green-500 transform hover:scale-110 transition duration-300">
                <i class="fab fa-whatsapp text-3xl"></i>
            </a>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var swiper = new Swiper('.swiper-container', {
                loop: true, // Untuk looping slide
                autoplay: {
                    delay: 4000, // Durasi setiap slide (4 detik)
                    disableOnInteraction: false, // Lanjutkan autoplay setelah interaksi pengguna
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
            });
        });
    </script>
</body>
</html>