<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

$query = "SELECT i.id, a.nik_anak, a.nama_anak, i.jenis_imunisasi, i.tanggal, i.keterangan, i.berat_badan, i.tinggi_badan, i.diagnosa 
          FROM imunisasi i 
          JOIN data_anak a ON i.anak_id = a.id 
          ORDER BY i.tanggal DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Manajemen Imunisasi - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-green-50 min-h-screen text-gray-800">
  <header class="bg-white shadow px-6 py-4 flex justify-between items-center">
    <h1 class="text-xl font-bold text-green-700">Manajemen Imunisasi</h1>
    <a href="indext_admin.php" class="text-green-600 hover:underline">← Kembali ke Dashboard</a>
  </header>

  <main class="p-6">
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-lg font-semibold">Daftar Imunisasi Anak</h2>
      <a href="tambah_imunisasi.php" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">+ Tambah Imunisasi</a>
    </div>

    <div class="overflow-auto bg-white rounded shadow">
      <table class="min-w-full text-sm table-auto border">
        <thead class="bg-green-100 text-green-800">
          <tr>
            <th class="px-4 py-2">#</th>
            <th class="px-4 py-2">NIK Anak</th>
            <th class="px-4 py-2">Nama Anak</th>
            <th class="px-4 py-2">Jenis Imunisasi</th>
            <th class="px-4 py-2">Tanggal</th>
            <th class="px-4 py-2">Berat (kg)</th>
            <th class="px-4 py-2">Tinggi (cm)</th>
            <th class="px-4 py-2">Diagnosa</th>
            <th class="px-4 py-2">Keterangan</th>
            <th class="px-4 py-2">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
            <tr class="border-b hover:bg-green-50">
              <td class="px-4 py-2"><?= $no++ ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['nik_anak']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['nama_anak']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['jenis_imunisasi']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['tanggal']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['berat_badan']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['tinggi_badan']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['diagnosa']) ?></td>
              <td class="px-4 py-2"><?= htmlspecialchars($row['keterangan']) ?></td>
              <td class="px-4 py-2 space-x-2">
                <a href="edit_imunisasi.php?id=<?= $row['id'] ?>" class="text-blue-600 hover:underline">Edit</a>
                <a href="hapus_imunisasi.php?id=<?= $row['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </main>
</body>
</html>
