<?php
session_start();
include 'koneksi.php'; // Pastikan file koneksi.php sudah ada dan berfungsi dengan benar

// Cek login & role admin
// Mengarahkan ke 'login_pengguna.php' jika tidak sesuai, atau ke halaman login utama Anda.
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login_pengguna.php");
    exit;
}

$error_message = '';
$success_message = '';

// PROSES UPDATE DATA
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil dan sanitasi input
    $id        = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $nik_anak  = isset($_POST['nik_anak']) ? trim($_POST['nik_anak']) : '';
    $nama_anak = isset($_POST['nama_anak']) ? trim($_POST['nama_anak']) : '';
    $tgl_lahir = isset($_POST['tgl_lahir']) ? trim($_POST['tgl_lahir']) : '';
    $nama_ibu  = isset($_POST['nama_ibu']) ? trim($_POST['nama_ibu']) : '';
    $nama_ayah = isset($_POST['nama_ayah']) ? trim($_POST['nama_ayah']) : '';
    $alamat    = isset($_POST['alamat']) ? trim($_POST['alamat']) : '';

    // Validasi dasar
    if (empty($id) || empty($nik_anak) || empty($nama_anak) || empty($tgl_lahir) || empty($nama_ibu) || empty($alamat)) {
        $error_message = "Semua kolom wajib diisi kecuali Nama Ayah (jika tidak ada).";
    } else {
        // Gunakan prepared statement untuk UPDATE
        $stmt = mysqli_prepare($conn, "UPDATE data_anak SET nik_anak=?, nama_anak=?, tgl_lahir=?, nama_ibu=?, nama_ayah=?, alamat=? WHERE id=?");

        if ($stmt === false) {
            $error_message = "Gagal menyiapkan statement: " . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, "ssssssi", $nik_anak, $nama_anak, $tgl_lahir, $nama_ibu, $nama_ayah, $alamat, $id);
            $sukses = mysqli_stmt_execute($stmt);

            if ($sukses) {
                // Redirect ke halaman daftar dengan pesan sukses
                header("Location: data_anak_admin.php?status=updated");
                exit;
            } else {
                $error_message = "Gagal update data: " . mysqli_stmt_error($stmt);
            }
            mysqli_stmt_close($stmt);
        }
    }
}

// MENAMPILKAN FORM DENGAN DATA YANG ADA (GET)
// Cek apakah ada ID yang dikirim
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Lebih baik redirect atau tampilkan pesan error yang user-friendly
    header("Location: data_anak_admin.php?status=error_id_missing");
    exit;
}

$id = intval($_GET['id']); // Pastikan ID adalah integer
$query = mysqli_query($conn, "SELECT * FROM data_anak WHERE id = '$id'"); // Query untuk mengambil data
$data = mysqli_fetch_assoc($query); // Ambil hasilnya

// Cek apakah data ditemukan
if (!$data) {
    // Redirect jika data tidak ditemukan
    header("Location: data_anak_admin.php?status=error_data_not_found");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Anak - Admin Posyandu Bina Cita</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-green-50 to-green-100 min-h-screen flex items-center justify-center py-10 px-4 sm:px-6 lg:px-8">

    <div class="bg-white p-8 sm:p-10 rounded-xl shadow-2xl w-full max-w-lg border border-green-200">
        <div class="flex justify-center mb-6">
            <svg class="h-16 w-16 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
        </div>
        <h2 class="text-3xl font-extrabold text-green-800 mb-4 text-center">Edit Data Anak</h2>
        <p class="text-center text-gray-600 mb-8">Perbarui informasi anak ini di sistem Posyandu.</p>

        <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6 text-sm" role="alert">
                <strong class="font-bold mr-1">Error!</strong>
                <span class="block sm:inline"><?= htmlspecialchars($error_message) ?></span>
            </div>
        <?php endif; ?>

        <form action="edit_data_anak_admin.php" method="POST" class="space-y-5">
            <input type="hidden" name="id" value="<?= htmlspecialchars($data['id']) ?>">
            
            <div>
                <label for="nik_anak" class="block text-sm font-semibold text-gray-700 mb-1">NIK Anak:</label>
                <input type="text" name="nik_anak" id="nik_anak" value="<?= htmlspecialchars($data['nik_anak']) ?>" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900" />
            </div>
            
            <div>
                <label for="nama_anak" class="block text-sm font-semibold text-gray-700 mb-1">Nama Anak:</label>
                <input type="text" name="nama_anak" id="nama_anak" value="<?= htmlspecialchars($data['nama_anak']) ?>" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900" />
            </div>
            
            <div>
                <label for="tgl_lahir" class="block text-sm font-semibold text-gray-700 mb-1">Tanggal Lahir:</label>
                <input type="date" name="tgl_lahir" id="tgl_lahir" value="<?= htmlspecialchars($data['tgl_lahir']) ?>" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900" />
            </div>
            
            <div>
                <label for="nama_ibu" class="block text-sm font-semibold text-gray-700 mb-1">Nama Ibu:</label>
                <input type="text" name="nama_ibu" id="nama_ibu" value="<?= htmlspecialchars($data['nama_ibu']) ?>" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900" />
            </div>
            
            <div>
                <label for="nama_ayah" class="block text-sm font-semibold text-gray-700 mb-1">Nama Ayah (Opsional):</label>
                <input type="text" name="nama_ayah" id="nama_ayah" value="<?= htmlspecialchars($data['nama_ayah']) ?>" class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900" />
            </div>
            
            <div>
                <label for="alamat" class="block text-sm font-semibold text-gray-700 mb-1">Alamat:</label>
                <textarea name="alamat" id="alamat" rows="3" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900"><?= htmlspecialchars($data['alamat']) ?></textarea>
            </div>

            <div class="flex justify-between items-center mt-6">
                <button type="submit" class="bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center">
                    <i class="fas fa-save mr-2"></i> Perbarui Data
                </button>
                <a href="data_anak_admin.php" class="text-gray-600 hover:text-green-800 transition duration-300 flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</body>
</html>