<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pengguna') {
  $_SESSION['redirect'] = $_GET['tujuan'] ?? 'dashboard_pengguna.php';
  header("Location: login_pengguna.php?redirect=" . $_SESSION['redirect']);
  exit;
} else {
  $tujuan = $_GET['tujuan'] ?? 'indext_pengguna.php';
  header("Location: $tujuan");
  exit;
}
?>
