<?php
session_start();
include 'koneksi.php'; // Pastikan file koneksi.php sudah ada dan berfungsi

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login_pengguna.php");
    exit;
}

$nama_admin = $_SESSION['nama'];

// Inisialisasi variabel untuk filter
$filter_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$filter_tahun = isset($_GET['tahun']) ? $_GET['tahun'] : '';

// Query untuk mengambil data laporan dengan JOIN ke tabel imunisasi
// Memilih kolom dari data_anak dan melakukan DISTINCT agar tidak ada duplikasi anak
// jika anak memiliki beberapa imunisasi pada bulan/tahun yang sama.
$query_laporan = "
    SELECT DISTINCT
        da.id,
        da.nik_anak,
        da.nama_anak,
        da.tgl_lahir,
        da.nama_ibu,
        da.nama_ayah,
        da.alamat
    FROM
        data_anak da
    INNER JOIN
        imunisasi i ON da.id = i.anak_id -- PERBAIKAN: Menggunakan 'anak_id' dari tabel imunisasi
";

$where_clauses = []; // Array untuk menampung kondisi WHERE

// Tambahkan kondisi filter jika bulan atau tahun dipilih
// Filter diterapkan pada kolom 'tanggal' dari tabel imunisasi
if (!empty($filter_bulan)) {
    $where_clauses[] = "MONTH(i.tanggal) = '" . mysqli_real_escape_string($conn, $filter_bulan) . "'"; // PERBAIKAN: Menggunakan 'tanggal'
}
if (!empty($filter_tahun)) {
    $where_clauses[] = "YEAR(i.tanggal) = '" . mysqli_real_escape_string($conn, $filter_tahun) . "'"; // PERBAIKAN: Menggunakan 'tanggal'
}

// Gabungkan kondisi WHERE jika ada
if (!empty($where_clauses)) {
    $query_laporan .= " WHERE " . implode(" AND ", $where_clauses);
}

// Tambahkan pengurutan
$query_laporan .= " ORDER BY da.nama_anak ASC";

$result_laporan = mysqli_query($conn, $query_laporan);

if (!$result_laporan) {
    die("Query gagal: " . mysqli_error($conn) . " Query: " . $query_laporan);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Data Imunisasi Anak - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: 'Poppins', sans-serif; }
        .navbar-blur { backdrop-filter: blur(12px); background-color: rgba(255, 255, 255, 0.7); }
        .table-auto-scroll {
            overflow-x: auto;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 to-green-100 text-gray-800">

    <header class="fixed top-0 left-0 right-0 z-50 navbar-blur shadow-lg">
        <div class="flex flex-col sm:flex-row justify-between items-center px-4 sm:px-8 py-3">
            <div class="flex items-center gap-3 mb-3 sm:mb-0">
                <img src="https://i.imgur.com/9rjiL5N.jpg" alt="Logo Posyandu" class="w-12 h-12 rounded-full object-cover border-2 border-green-600 shadow-md" />
                <span class="text-xl font-bold text-green-800">Dashboard Kader Posyandu</span>
            </div>
            <div class="text-sm sm:text-base text-green-800 font-semibold flex items-center">
                <i class="fas fa-hand-sparkles text-yellow-500 mr-2"></i> Selamat datang, <span class="font-bold ml-1 mr-4"><?= htmlspecialchars($nama_admin) ?></span>
                <a href="logout.php" class="bg-red-500 text-white px-4 py-2 rounded-full hover:bg-red-600 transition duration-300 ease-in-out transform hover:scale-105 flex items-center text-sm">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </a>
            </div>
        </div>
    </header>

    <main class="pt-24 pb-10 px-4 sm:px-6 lg:px-8">
        <div class="bg-white p-6 sm:p-8 rounded-xl shadow-2xl border border-green-200">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-3xl font-extrabold text-green-800 flex items-center">
                    <i class="fas fa-chart-line text-green-600 mr-3"></i> Laporan Data Imunisasi Anak
                </h2>
                <a href="indext_admin.php" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300 transition duration-300 flex items-center text-sm">
                    <i class="fas fa-arrow-left mr-2"></i> Kembali ke Dashboard
                </a>
            </div>

            <p class="text-gray-600 mb-8">
                Tinjau data anak-anak yang telah melakukan imunisasi pada bulan dan tahun tertentu.
            </p>

            <div class="mb-6 bg-green-50 p-4 rounded-lg border border-green-200">
                <form action="laporan.php" method="GET" class="flex flex-col sm:flex-row gap-4 items-end">
                    <div class="w-full sm:w-1/3">
                        <label for="bulan" class="block text-sm font-medium text-gray-700 mb-1">Filter Bulan Imunisasi:</label>
                        <select id="bulan" name="bulan" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm">
                            <option value="">-- Semua Bulan --</option>
                            <?php
                            $months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                            for ($i = 1; $i <= 12; $i++) {
                                $month_num = str_pad($i, 2, '0', STR_PAD_LEFT);
                                $selected = ($filter_bulan == $month_num) ? 'selected' : '';
                                echo "<option value=\"$month_num\" $selected>" . $months[$i-1] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="w-full sm:w-1/3">
                        <label for="tahun" class="block text-sm font-medium text-gray-700 mb-1">Filter Tahun Imunisasi:</label>
                        <select id="tahun" name="tahun" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm">
                            <option value="">-- Semua Tahun --</option>
                            <?php
                            $current_year = date('Y');
                            // Asumsikan data imunisasi ada dari beberapa tahun ke belakang
                            $start_year = 2020; // Sesuaikan dengan tahun awal data imunisasi Anda
                            $end_year = $current_year + 1; // Atau sampai tahun berjalan + 1 jika ada jadwal ke depan

                            for ($y = $end_year; $y >= $start_year; $y--) {
                                $selected = ($filter_tahun == $y) ? 'selected' : '';
                                echo "<option value=\"$y\" $selected>$y</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="w-full sm:w-1/3 flex justify-end sm:justify-start">
                         <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition duration-300 flex items-center justify-center w-full sm:w-auto">
                            <i class="fas fa-filter mr-2"></i> Terapkan Filter
                        </button>
                        <a href="laporan.php" class="ml-2 bg-gray-400 text-white px-6 py-2 rounded-lg hover:bg-gray-500 transition duration-300 flex items-center justify-center w-full sm:w-auto">
                            <i class="fas fa-redo mr-2"></i> Reset
                        </a>
                    </div>
                </form>
            </div>


            <div class="table-auto-scroll rounded-lg shadow-md border border-gray-200">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-green-100">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">No.</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">NIK Anak</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">Nama Anak</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">Tgl. Lahir</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">Nama Ibu</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">Nama Ayah</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-green-700 uppercase tracking-wider">Alamat</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php
                        $no = 1;
                        if (mysqli_num_rows($result_laporan) > 0) {
                            while ($row = mysqli_fetch_assoc($result_laporan)) {
                                ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= $no++ ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($row['nik_anak']) ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($row['nama_anak']) ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars(date('d F Y', strtotime($row['tgl_lahir']))) ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($row['nama_ibu']) ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($row['nama_ayah']) ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($row['alamat']) ?></td>
                                </tr>
                                <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="7" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center">Tidak ada data anak yang melakukan imunisasi pada periode ini.</td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-8 text-right">
                <button onclick="window.print()" class="bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700 transition duration-300 flex items-center justify-end ml-auto">
                    <i class="fas fa-print mr-2"></i> Cetak Laporan
                </button>
            </div>

        </div>
    </main>

    <footer class="bg-white border-t border-green-200 py-6">
        <div class="text-center text-sm text-gray-600">
            &copy; <?= date('Y') ?> Posyandu Bina Cita. Semua Hak Dilindungi.
        </div>
    </footer>

</body>
</html>