<?php
// ==== edit_imunisasi.php ====
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

// Ambil ID dari parameter GET
if (!isset($_GET['id'])) {
  die("ID tidak ditemukan.");
}
$id = $_GET['id'];

// Ambil data imunisasi berdasarkan ID
$query = mysqli_query($conn, "SELECT * FROM imunisasi WHERE id = '$id'");
$data = mysqli_fetch_assoc($query);
if (!$data) {
  die("Data tidak ditemukan.");
}

// Ambil data anak untuk dropdown
$anak_result = mysqli_query($conn, "SELECT id, nik_anak, nama_anak FROM data_anak ORDER BY nama_anak ASC");

// Proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $anak_id      = $_POST['anak_id'];
  $jenis        = $_POST['jenis_imunisasi'];
  $tgl          = $_POST['tanggal'];
  $berat_badan  = $_POST['berat_badan'];
  $tinggi_badan = $_POST['tinggi_badan'];
  $diagnosa     = $_POST['diagnosa'];
  $ket          = $_POST['keterangan'];

  $stmt = mysqli_prepare($conn, "UPDATE imunisasi SET anak_id=?, jenis_imunisasi=?, tanggal=?, berat_badan=?, tinggi_badan=?, diagnosa=?, keterangan=? WHERE id=?");
  mysqli_stmt_bind_param($stmt, "issddssi", $anak_id, $jenis, $tgl, $berat_badan, $tinggi_badan, $diagnosa, $ket, $id);
  mysqli_stmt_execute($stmt);

  header("Location: imunisasi_pengguna.php?status=updated");
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Imunisasi</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-green-50 min-h-screen flex items-center justify-center">
  <div class="bg-white p-8 rounded shadow w-full max-w-lg">
    <h2 class="text-2xl font-bold text-green-700 mb-4">Edit Data Imunisasi</h2>
    <form method="POST">
      <label class="block mb-2 font-medium">Pilih Anak:</label>
      <select name="anak_id" required class="w-full mb-4 px-4 py-2 border rounded">
        <?php while ($anak = mysqli_fetch_assoc($anak_result)): ?>
          <option value="<?= $anak['id'] ?>" <?= $anak['id'] == $data['anak_id'] ? 'selected' : '' ?> >
            <?= htmlspecialchars($anak['nik_anak']) ?> - <?= htmlspecialchars($anak['nama_anak']) ?>
          </option>
        <?php endwhile; ?>
      </select>

      <input type="text" name="jenis_imunisasi" value="<?= $data['jenis_imunisasi'] ?>" required class="w-full mb-3 px-4 py-2 border rounded" />
      <input type="date" name="tanggal" value="<?= $data['tanggal'] ?>" required class="w-full mb-3 px-4 py-2 border rounded" />
      <div class="flex gap-4">
        <input type="number" step="0.01" name="berat_badan" value="<?= $data['berat_badan'] ?>" required class="w-1/2 px-4 py-2 border rounded mb-3" />
        <input type="number" step="0.01" name="tinggi_badan" value="<?= $data['tinggi_badan'] ?>" required class="w-1/2 px-4 py-2 border rounded mb-3" />
      </div>
      <input type="text" name="diagnosa" value="<?= $data['diagnosa'] ?>" class="w-full mb-3 px-4 py-2 border rounded" />
      <textarea name="keterangan" class="w-full mb-4 px-4 py-2 border rounded"><?= $data['keterangan'] ?></textarea>

      <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700 transition">Update</button>
      <a href="imunisasi_pengguna.php" class="ml-4 text-sm text-green-600 hover:underline">← Kembali</a>
    </form>
  </div>
</body>
</html>
