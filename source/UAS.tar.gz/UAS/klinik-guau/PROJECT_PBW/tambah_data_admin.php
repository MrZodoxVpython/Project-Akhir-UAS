<?php
session_start();
include 'koneksi.php'; // Pastikan file koneksi.php sudah ada dan berfungsi dengan benar

// Cek login admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Proses submit
$error = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik_anak  = trim($_POST['nik_anak']);
    $nama_anak = trim($_POST['nama_anak']);
    $tgl_lahir = $_POST['tgl_lahir'];
    $nama_ibu  = trim($_POST['nama_ibu']);
    $nama_ayah = trim($_POST['nama_ayah']);
    $alamat    = trim($_POST['alamat']);

    // Validasi dasar
    if (empty($nik_anak) || empty($nama_anak) || empty($tgl_lahir) || empty($nama_ibu) || empty($nama_ayah) || empty($alamat)) {
        $error = "Semua kolom wajib diisi.";
    } else {
        // Cari user_id berdasarkan nama ibu
        // Gunakan prepared statement untuk menghindari SQL Injection
        $stmt_user = mysqli_prepare($conn, "SELECT id FROM users WHERE nama = ? AND role = 'pengguna' LIMIT 1");
        mysqli_stmt_bind_param($stmt_user, "s", $nama_ibu);
        mysqli_stmt_execute($stmt_user);
        $cari_user_result = mysqli_stmt_get_result($stmt_user);
        $user_data = mysqli_fetch_assoc($cari_user_result);
        mysqli_stmt_close($stmt_user);

        if ($user_data) {
            $user_id = intval($user_data['id']);

            // Simpan data anak
            $stmt = mysqli_prepare($conn, "INSERT INTO data_anak (nik_anak, nama_anak, tgl_lahir, nama_ibu, nama_ayah, alamat, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "ssssssi", $nik_anak, $nama_anak, $tgl_lahir, $nama_ibu, $nama_ayah, $alamat, $user_id);

            if (mysqli_stmt_execute($stmt)) {
                header("Location: data_anak_admin.php?status=sukses");
                exit;
            } else {
                $error = "Gagal menyimpan data: " . mysqli_error($conn);
            }
            mysqli_stmt_close($stmt); // Tutup statement setelah digunakan
        } else {
            $error = "Data pengguna dengan nama ibu '$nama_ibu' tidak ditemukan. Pastikan nama ibu sudah terdaftar sebagai pengguna.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Anak - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* CSS Kustom (opsional, untuk scrollbar jika diinginkan) */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #cbd5e0;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #a0aec0;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 to-green-100 min-h-screen flex items-center justify-center py-10 px-4 sm:px-6 lg:px-8">
    <div class="bg-white p-8 sm:p-10 rounded-xl shadow-2xl w-full max-w-md border border-green-200">
        <div class="flex justify-center mb-6">
            <svg class="h-16 w-16 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM12 10v2a4 4 0 00-4 4v2H6a2 2 0 01-2-2v-4a2 2 0 012-2h4z" />
            </svg>
        </div>
        <h2 class="text-3xl font-extrabold text-green-800 text-center mb-6">Tambah Data Anak</h2>
        <p class="text-center text-gray-600 mb-8">Isi formulir di bawah ini untuk menambahkan data anak baru.</p>

        <?php if (!empty($error)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6" role="alert">
                <strong class="font-bold">Error!</strong>
                <span class="block sm:inline"><?= htmlspecialchars($error) ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-5">
            <div>
                <label for="nik_anak" class="block text-sm font-semibold text-gray-700 mb-1">NIK Anak:</label>
                <input type="text" id="nik_anak" name="nik_anak" placeholder="Contoh: 3526XXXXXXXXXXXXXX" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900 placeholder-gray-400">
            </div>

            <div>
                <label for="nama_anak" class="block text-sm font-semibold text-gray-700 mb-1">Nama Anak:</label>
                <input type="text" id="nama_anak" name="nama_anak" placeholder="Contoh: Budi Santoso" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900 placeholder-gray-400">
            </div>

            <div>
                <label for="tgl_lahir" class="block text-sm font-semibold text-gray-700 mb-1">Tanggal Lahir:</label>
                <input type="date" id="tgl_lahir" name="tgl_lahir" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900">
            </div>

            <div>
                <label for="nama_ibu" class="block text-sm font-semibold text-gray-700 mb-1">Nama Ibu (sesuai akun pengguna):</label>
                <input type="text" id="nama_ibu" name="nama_ibu" placeholder="Contoh: Siti Aminah" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900 placeholder-gray-400">
                <p class="mt-1 text-xs text-gray-500">Pastikan nama ibu sudah terdaftar sebagai pengguna.</p>
            </div>

            <div>
                <label for="nama_ayah" class="block text-sm font-semibold text-gray-700 mb-1">Nama Ayah:</label>
                <input type="text" id="nama_ayah" name="nama_ayah" placeholder="Contoh: Budi Hartono" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900 placeholder-gray-400">
            </div>

            <div>
                <label for="alamat" class="block text-sm font-semibold text-gray-700 mb-1">Alamat:</label>
                <textarea id="alamat" name="alamat" rows="3" placeholder="Contoh: Jl. Merdeka No. 123, Bangkalan" required class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-green-500 focus:border-green-500 text-gray-900 placeholder-gray-400"></textarea>
            </div>

            <div class="flex flex-col sm:flex-row justify-between items-center pt-4 gap-4">
                <button type="submit" class="w-full sm:w-auto bg-green-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition duration-300 ease-in-out transform hover:scale-105">
                    <i class="fas fa-save mr-2"></i> Simpan Data
                </button>
                <a href="data_anak_admin.php" class="text-green-600 hover:text-green-800 font-semibold transition duration-300 ease-in-out flex items-center">
                    <i class="fas fa-arrow-left mr-2"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</body>
</html>