#buat database e_posyandu
sudo mysql -u root -p

CREATE DATABASE e_posyandu;
CREATE USER 'benjamin'@'localhost' IDENTIFIED BY 'wickman';
GRANT ALL PRIVILEGES ON e_posyandu.* TO 'benjamin'@'localhost';
FLUSH PRIVILEGES;
EXIT;

#buat tabel roles
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO roles (role_name) VALUES ('peserta'), ('kader');

#buat tabel users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

