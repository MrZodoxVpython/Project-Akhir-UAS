<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?error=Silakan login dulu");
    exit;
}
// Ambil data dari session
$nama = $_SESSION['nama'] ?? '';
$email = $_SESSION['email'] ?? '';
$role_id = $_SESSION['role_id'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Peserta - E-Posyandu Bina Cita</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">
    <!-- Header -->
    <header class="bg-blue-600 text-white p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-xl font-semibold">Dashboard Peserta</h1>
	    <h2>Selamat Datang di E-Posyandu Bina Cita</h2>
    	    <p>Halo, <strong><?= htmlspecialchars($nama) ?></strong>! (<?= htmlspecialchars($email) ?>)</p>
            <p>Role ID Anda: <?= htmlspecialchars($role_id) ?></p>
        </div>
    </header>

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside class="w-64 bg-gray-800 text-white py-6 px-4 hidden md:block">
            <nav>
                <ul class="space-y-4">
                    <li><a href="#" class="block py-2 px-4 hover:bg-gray-700 rounded">Beranda</a></li>
                    <li><a href="#" class="block py-2 px-4 hover:bg-gray-700 rounded">Data Kesehatan Anak</a></li>
                    <li><a href="#" class="block py-2 px-4 hover:bg-gray-700 rounded">Jadwal Posyandu</a></li>
                    <li><a href="#" class="block py-2 px-4 hover:bg-gray-700 rounded">Pemeriksaan Balita</a></li>
                    <li><a href="#" class="block py-2 px-4 hover:bg-gray-700 rounded">Riwayat Kunjungan</a></li>
                    <li><a href="#" class="block py-2 px-4 hover:bg-gray-700 rounded">Profil Saya</a></li>
                    <li><a href="logout.php" class="block py-2 px-4 bg-red-500 hover:bg-red-600 rounded text-center">Logout</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Card 1 -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="text-lg font-semibold mb-2">Informasi Terkini</h2>
                    <p>Selamat datang di sistem E-Posyandu Bina Cita. Di sini Anda dapat melihat jadwal posyandu, mencatat pemeriksaan balita, dan mengakses riwayat kesehatan keluarga Anda.</p>
                </div>
                <!-- Card 2 -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="text-lg font-semibold mb-2">Statistik Kunjungan</h2>
                    <ul class="list-disc pl-5 space-y-1">
                        <li>Total Kunjungan: <strong>12 kali</strong></li>
                        <li>Kunjungan Terakhir: <strong>10 Juni 2025</strong></li>
                    </ul>
                </div>
                <!-- Card 3 -->
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="text-lg font-semibold mb-2">Jadwal Posyandu Berikutnya</h2>
                    <p>📅 Tanggal: <strong>15 Juni 2025</strong></p>
                    <p>🕒 Waktu: <strong>08:00 - 11:00 WIB</strong></p>
                    <p>📍 Lokasi: <strong>Balai RW 05, Kelurahan Bina Cita</strong></p>
                </div>
            </div>

            <!-- Tambahan Konten Lain -->
            <div class="mt-10">
                <h2 class="text-2xl font-bold mb-4">Riwayat Pemeriksaan Balita</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white rounded shadow">
                        <thead class="bg-gray-200 text-gray-700">
                            <tr>
                                <th class="py-2 px-4 text-left">Tanggal</th>
                                <th class="py-2 px-4 text-left">Nama Anak</th>
                                <th class="py-2 px-4 text-left">Berat Badan</th>
                                <th class="py-2 px-4 text-left">Tinggi Badan</th>
                                <th class="py-2 px-4 text-left">Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr class="border-t">
                                <td class="py-2 px-4">01 Juni 2025</td>
                                <td class="py-2 px-4">Aulia Rahma</td>
                                <td class="py-2 px-4">10.5 kg</td>
                                <td class="py-2 px-4">85 cm</td>
                                <td class="py-2 px-4">Sehat</td>
                            </tr>
                            <!-- Tambahkan baris lainnya sesuai kebutuhan -->
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <footer class="text-center text-sm text-gray-500 mt-10 pb-4">
        &copy; <?= date('Y') ?> E-Posyandu Bina Cita. All rights reserved.
    </footer>
</body>
</html>

