<?php
session_start();

// Tampilkan error untuk debugging (bisa dimatikan di production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Koneksi ke database
include 'koneksi.php';

// Ambil data dari form login
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$login_type = $_POST['login_type'] ?? 'peserta'; // Default: peserta

// Validasi input kosong
if (empty($email) || empty($password)) {
    if ($login_type === 'admin') {
        header("Location: admin.php?error=Email dan password harus diisi");
    } else {
        header("Location: login.php?error=Email dan password harus diisi");
    }
    exit;
}

// Cek data user di database
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

// Apakah user ditemukan?
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // Cocokkan password dengan hash
    if (password_verify($password, $user['password'])) {
        // Jika login sebagai admin tapi bukan role admin, tolak
        if ($login_type === 'admin' && $user['role_id'] != 1) {
            header("Location: admin.php?error=Akun ini bukan admin");
            exit;
        }

        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['nama'] = $user['nama'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role_id'] = $user['role_id'];

        // Arahkan ke dashboard sesuai role
        if ($user['role_id'] == 1 && $login_type === 'admin') {
            header("Location: dashboard_admin.php");
        } else {
            header("Location: dashboard.php");
        }
        exit;

    } else {
        $err = "Password salah";
        if ($login_type === 'admin') {
            header("Location: admin.php?error=$err");
        } else {
            header("Location: login.php?error=$err");
        }
        exit;
    }

} else {
    $err = "Email tidak ditemukan";
    if ($login_type === 'admin') {
        header("Location: admin.php?error=$err");
    } else {
        header("Location: login.php?error=$err");
    }
    exit;
}
?>

