<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Beranda - E-Posyandu Bina Cita</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    .no-scrollbar::-webkit-scrollbar {
      display: none;
    }
    .no-scrollbar {
      -ms-overflow-style: none;
      scrollbar-width: none;
    }
    
    @keyframes slide {
    0% { transform: translateX(0); }
    33% { transform: translateX(-100%); }
    66% { transform: translateX(-200%); }
    100% { transform: translateX(0); }
    }
    .animate-slide {
    width: 100%;
    display: flex;
    animation: slide 12s infinite ease-in-out;
    }
  </style>
</head>
<body class="bg-gradient-to-b from-blue-50 to-white min-h-screen font-sans text-gray-800">

  <!-- Header -->
  <header class="text-center py-8">
    <h1 class="text-4xl font-bold text-blue-700">E-Posyandu Bina Cita</h1>
    <p class="text-lg text-gray-600 mt-2">Sistem informasi posyandu digital yang modern dan terpercaya</p>
  </header>

  <!-- Auto Slide Image Carousel -->
  <div class="relative w-full overflow-hidden">
  <div class="flex animate-slide">
    <!-- Slide 1 -->
    <div class="relative w-full flex-shrink-0 aspect-video">
      <img src="assets/slide1.jpg" class="w-full h-full object-cover" alt="Slide 1" />
      <div class="absolute inset-0 bg-black bg-opacity-25"></div>
      <div class="absolute inset-0 flex flex-col items-center justify-center text-white text-center z-10 px-4">
        <h2 class="text-2xl font-bold mb-2">Informasi Posyandu 1</h2>
        <p class="text-base">Jadwal pemeriksaan balita dan ibu hamil.</p>
      </div>
    </div>


    <!-- Slide 2 -->
    <div class="relative w-full flex-shrink-0 aspect-video">
      <img src="assets/slide2.jpg" class="w-full h-full object-cover" alt="Slide 1" />
      <div class="absolute inset-0 bg-black bg-opacity-25"></div>
      <div class="absolute inset-0 flex flex-col items-center justify-center text-white text-center z-10 px-4">
        <h2 class="text-xl font-semibold">Pemberian Vitamin A</h2>
        <p class="text-sm">Jangan lupa datang bulan depan!</p>
      </div>
    </div>

    <!-- Slide 3 -->
    <div class="relative w-full flex-shrink-0 aspect-video">
      <img src="assets/slide3.jpg" class="w-full h-full object-cover" alt="Slide 1" />
      <div class="absolute inset-0 bg-black bg-opacity-25"></div>
      <div class="absolute inset-0 flex flex-col items-center justify-center text-white text-center z-10 px-4">
        <h2 class="text-xl font-semibold">Edukasi Gizi Balita</h2>
        <p class="text-sm">Materi baru setiap minggu.</p>
      </div>
    </div>
  </div>
  </div>


  <!-- Tombol Login -->
  <div class="text-center mt-10">
    <a href="login.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-xl shadow">
      Login ke Sistem
    </a>
  </div>

  <!-- Informasi Menarik -->
  <section class="mt-16 px-6 max-w-5xl mx-auto">
    <h2 class="text-2xl font-bold text-blue-700 mb-4">Informasi Terbaru</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php
      $infoList = [
        ["icon" => "🍼", "judul" => "Jadwal Posyandu", "isi" => "Kegiatan posyandu berikutnya akan diadakan pada 20 Juni 2025, pukul 08.00 WIB di balai warga RW 03."],
        ["icon" => "💉", "judul" => "Imunisasi Gratis", "isi" => "Pastikan anak Anda mendapatkan imunisasi lengkap sesuai jadwal yang tersedia setiap bulan."],
        ["icon" => "📊", "judul" => "Pantau Perkembangan", "isi" => "Gunakan sistem ini untuk mencatat dan memantau pertumbuhan balita Anda secara digital."],
        ["icon" => "👩‍⚕️", "judul" => "Konsultasi Gizi", "isi" => "Tersedia layanan konsultasi gizi bersama ahli gizi untuk anak Anda setiap hari Rabu."],
        ["icon" => "🥗", "judul" => "Tips Sehat", "isi" => "Cek artikel kami tentang makanan sehat untuk ibu hamil dan menyusui."],
        ["icon" => "🎓", "judul" => "Edukasi Ibu", "isi" => "Ikuti kelas online gratis mengenai pengasuhan anak, kesehatan ibu, dan nutrisi."]
      ];
      foreach ($infoList as $info) {
        echo "
        <div class='bg-white rounded-xl shadow p-6 hover:shadow-lg transition'>
          <div class='text-4xl mb-2'>{$info['icon']}</div>
          <h3 class='text-xl font-semibold mb-1 text-blue-600'>{$info['judul']}</h3>
          <p class='text-gray-600 text-sm'>{$info['isi']}</p>
        </div>
        ";
      }
      ?>
    </div>
  </section>

  <!-- Footer -->
  <footer class="text-center text-gray-500 text-sm mt-20 mb-6">
    &copy; <?= date('Y') ?> E-Posyandu Bina Cita. Semua hak dilindungi.
  </footer>

</body>
</html>

