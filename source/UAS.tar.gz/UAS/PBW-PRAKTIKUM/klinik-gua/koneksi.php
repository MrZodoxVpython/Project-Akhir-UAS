<?php
// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ganti ini sesuai dengan database dan kredensial kamu
$host = 'localhost';
$user = 'benjamin';
$pass = 'wickman';
$db   = 'e_posyandu';

// Koneksi ke MySQL
$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}
?>

