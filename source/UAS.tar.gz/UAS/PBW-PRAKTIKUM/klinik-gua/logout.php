<?php
session_start();
session_destroy(); // Hapus semua session
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout - E-Posyandu Bina Cita</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-200 to-blue-400 min-h-screen flex items-center justify-center font-sans">
    <div class="bg-white shadow-xl rounded-2xl px-10 py-12 max-w-md w-full text-center">
        <h1 class="text-3xl font-bold text-blue-600 mb-4">Anda telah logout</h1>
        <p class="text-gray-700 mb-6">Terima kasih telah menggunakan sistem E-Posyandu Bina Cita.</p>

        <a href="index.php" class="inline-block bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-5 rounded-full transition">
            Kembali ke Beranda
        </a>

        <div class="mt-8 text-sm text-gray-500">
            &copy; <?= date('Y') ?> E-Posyandu Bina Cita
        </div>
    </div>
</body>
</html>

