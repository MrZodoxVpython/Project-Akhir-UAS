<?php
session_start();
if (isset($_SESSION['user_id']) && $_SESSION['role_id'] == 1) {
    header("Location: dashboard_admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Login Admin - E-Posyandu Bina Cita</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background-color: #0d0d0d;
      font-family: 'Courier New', monospace;
    }

    .login-box {
      position: relative;
      background: #111;
      padding: 2rem;
      border-radius: 1rem;
      overflow: hidden;
      max-width: 400px;
      margin: auto;
    }

    .login-box h2 {
      color: #00fff7;
      text-align: center;
      margin-bottom: 1.5rem;
      text-shadow: 0 0 10px #00fff7, 0 0 20px #00fff7;
    }

    .login-box form label {
      color: #a0fdfd;
    }

    .login-box form input {
      background: #000;
      border: 1px solid #333;
      color: #fff;
    }

    .login-box form input:focus {
      outline: none;
      border-color: #00fff7;
      box-shadow: 0 0 10px #00fff7;
    }

    .neon-btn {
      background: #00fff7;
      color: #000;
      font-weight: bold;
      transition: 0.3s;
      box-shadow: 0 0 10px #00fff7, 0 0 20px #00fff7;
    }

    .neon-btn:hover {
      background: #00e5d4;
      box-shadow: 0 0 20px #00fff7, 0 0 40px #00fff7;
    }

    /* Border animasi */
    .login-box span {
      position: absolute;
      display: block;
    }

    .login-box span:nth-child(1) {
      top: 0;
      left: 0;
      width: 100%;
      height: 2px;
      background: linear-gradient(90deg, transparent, #00fff7);
      animation: animate1 2s linear infinite;
    }

    .login-box span:nth-child(2) {
      top: 0;
      right: 0;
      width: 2px;
      height: 100%;
      background: linear-gradient(180deg, transparent, #00fff7);
      animation: animate2 2s linear infinite;
      animation-delay: 0.5s;
    }

    .login-box span:nth-child(3) {
      bottom: 0;
      right: 0;
      width: 100%;
      height: 2px;
      background: linear-gradient(270deg, transparent, #00fff7);
      animation: animate3 2s linear infinite;
      animation-delay: 1s;
    }

    .login-box span:nth-child(4) {
      bottom: 0;
      left: 0;
      width: 2px;
      height: 100%;
      background: linear-gradient(360deg, transparent, #00fff7);
      animation: animate4 2s linear infinite;
      animation-delay: 1.5s;
    }

    @keyframes animate1 {
      0% { left: -100%; }
      100% { left: 100%; }
    }

    @keyframes animate2 {
      0% { top: -100%; }
      100% { top: 100%; }
    }

    @keyframes animate3 {
      0% { right: -100%; }
      100% { right: 100%; }
    }

    @keyframes animate4 {
      0% { bottom: -100%; }
      100% { bottom: 100%; }
    }
  </style>
</head>
<body class="flex items-center justify-center min-h-screen">

  <div class="login-box">
    <!-- Neon border lines -->
    <span></span><span></span><span></span><span></span>

    <h2>Login Admin</h2>

    <?php if (isset($_GET['error'])): ?>
      <div class="bg-red-800 text-red-300 p-3 mb-4 rounded border border-red-500 text-sm">
        <?= htmlspecialchars($_GET['error']) ?>
      </div>
    <?php endif; ?>

    <form action="proses_login.php" method="post" class="space-y-4">
      <input type="hidden" name="login_type" value="admin">
      <div>
        <label for="email" class="block text-sm font-medium">Email</label>
        <input type="email" id="email" name="email" required
               class="w-full p-2 rounded neon-input">
      </div>
      <div>
        <label for="password" class="block text-sm font-medium">Password</label>
        <input type="password" id="password" name="password" required
               class="w-full p-2 rounded neon-input">
      </div>
      <button type="submit"
              class="w-full py-2 rounded neon-btn hover:scale-105 transition-transform duration-200">
        Masuk Dashboard
      </button>
    </form>
  </div>

<audio id="bg-audio" src="https://nathanprinsley-files.prinsh.com/data-1/mp3/beat-hackers_experience.mp3" autoplay loop></audio>

<script>
  const audio = document.getElementById('bg-audio');

  // Browser modern mencegah autoplay jika tanpa interaksi user
  document.addEventListener('DOMContentLoaded', () => {
    const playAudio = () => {
      audio.play().catch(() => {
        // Jika autoplay dicegah, tampilkan tombol manual
        const btn = document.createElement('button');
        btn.textContent = "🎵 Klik untuk nyalakan musik";
        btn.className = "fixed bottom-4 left-4 px-4 py-2 bg-cyan-500 text-white rounded shadow-xl hover:bg-cyan-700 z-50";
        btn.onclick = () => {
          audio.play();
          btn.remove(); // Hapus tombol setelah dipakai
        };
        document.body.appendChild(btn);
      });
    };

    playAudio();
  });
</script>

</body>
</html>

