<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role_id'] != 1) {
    header("Location: admin.php?error=Silakan login sebagai admin");
    exit;
}

$nama = $_SESSION['nama'];
$email = $_SESSION['email'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - E-Posyandu Bina Cita</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1d4ed8',
                        secondary: '#64748b',
                        accent: '#10b981',
                    },
                }
            }
        }
    </script>
    <link href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/tabler-icons.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 font-sans text-gray-800">

    <!-- Header -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="container mx-auto px-6 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-semibold text-primary">E-Posyandu Admin</h1>
            <div class="text-right">
                <p class="text-sm">Halo, <strong><?= htmlspecialchars($nama) ?></strong></p>
                <p class="text-xs text-gray-500"><?= htmlspecialchars($email) ?></p>
                <a href="logout.php" class="text-sm text-red-600 hover:underline mt-1 inline-block">Logout</a>
            </div>
        </div>
    </header>

    <!-- Main content -->
    <main class="container mx-auto px-6 py-10">
        <h2 class="text-3xl font-bold mb-8">Manajemen Sistem</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            
            <!-- Card 1 -->
            <a href="crud_users.php" class="group bg-white rounded-xl p-6 shadow-md hover:shadow-xl hover:border-blue-600 transition duration-300 border border-transparent">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-semibold text-primary">Data Pengguna</h3>
                    <i class="ti ti-users text-2xl text-gray-400 group-hover:text-primary"></i>
                </div>
                <p class="text-sm text-gray-600">Lihat, tambah, edit, dan hapus akun peserta & kader.</p>
            </a>

            <!-- Card 2 -->
            <a href="crud_jadwal.php" class="group bg-white rounded-xl p-6 shadow-md hover:shadow-xl hover:border-blue-600 transition duration-300 border border-transparent">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-semibold text-primary">Jadwal Posyandu</h3>
                    <i class="ti ti-calendar-event text-2xl text-gray-400 group-hover:text-primary"></i>
                </div>
                <p class="text-sm text-gray-600">Kelola jadwal kegiatan posyandu secara menyeluruh.</p>
            </a>

            <!-- Card 3 -->
            <a href="crud_laporan.php" class="group bg-white rounded-xl p-6 shadow-md hover:shadow-xl hover:border-blue-600 transition duration-300 border border-transparent">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-semibold text-primary">Laporan Kesehatan</h3>
                    <i class="ti ti-file-description text-2xl text-gray-400 group-hover:text-primary"></i>
                </div>
                <p class="text-sm text-gray-600">Pantau dan kelola data kesehatan balita dan ibu.</p>
            </a>
        </div>
    </main>

    <!-- Footer -->
    <footer class="text-center text-gray-500 text-sm py-6 border-t mt-10">
        &copy; <?= date('Y') ?> E-Posyandu Bina Cita. All rights reserved.
    </footer>

</body>
</html>
