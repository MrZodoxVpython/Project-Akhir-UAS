<?php
session_start();
$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login / Register - E-Posyandu</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; }
    .tab-btn { transition: all 0.3s; }
    .tab-btn.active {
      border-bottom: 2px solid #059669;
      font-weight: 600;
      color: #059669;
    }
    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-10px); }
    }
    .animate-float {
      animation: float 6s ease-in-out infinite;
    }
  </style>
</head>
<body class="relative min-h-screen flex items-center justify-center px-4 overflow-hidden bg-gradient-to-br from-emerald-50 to-white">

  <!-- Latar belakang animasi -->
  <div class="absolute w-[500px] h-[500px] bg-gradient-to-br from-emerald-300 via-teal-300 to-white rounded-full blur-3xl opacity-30 top-[-100px] left-[-100px] animate-pulse"></div>
  <div class="absolute w-[400px] h-[400px] bg-gradient-to-tr from-emerald-200 via-white to-teal-300 rounded-full blur-2xl opacity-30 bottom-[-100px] right-[-100px] animate-ping"></div>

  <!-- Card Form -->
  <div class="bg-white rounded-3xl shadow-2xl p-8 md:p-12 w-full max-w-md z-10">
    <!-- Tabs -->
    <div class="flex justify-center space-x-6 mb-6 border-b border-gray-200 pb-4">
      <button onclick="showTab('login')" id="tabLogin" class="tab-btn active">Login</button>
      <button onclick="showTab('register')" id="tabRegister" class="tab-btn">Register</button>
    </div>

    <!-- Alert Message -->
    <?php if ($success): ?>
      <div class="mb-4 p-3 text-sm bg-green-100 text-green-700 border border-green-300 rounded-md">
        <?= htmlspecialchars($success) ?>
      </div>
    <?php elseif ($error): ?>
      <div class="mb-4 p-3 text-sm bg-red-100 text-red-700 border border-red-300 rounded-md">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <!-- Form Login -->
    <div id="loginForm">
      <h2 class="text-xl font-bold text-emerald-700 text-center mb-4">Login Pengguna</h2>
      <form id="formLogin" action="proses_login.php" method="POST" class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-600">Email</label>
          <input id="loginEmail" type="email" name="email" required class="mt-1 w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-300 transition-all duration-200">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-600">Password</label>
          <input id="loginPassword" type="password" name="password" required class="mt-1 w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-300 transition-all duration-200">
        </div>
        <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2 rounded-lg transition-all duration-200">
          Masuk
        </button>
      </form>
    </div>

    <!-- Form Register -->
    <div id="registerForm" class="hidden">
      <h2 class="text-xl font-bold text-teal-700 text-center mb-4">Daftar Akun Baru</h2>
      <form id="formRegister" action="proses_register.php" method="POST" class="space-y-4">
        <div>
          <label class="block text-sm font-medium text-gray-600">Nama Lengkap</label>
          <input type="text" name="nama" required class="mt-1 w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-300 transition-all duration-200">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-600">Email</label>
          <input id="registerEmail" type="email" name="email" required class="mt-1 w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-300 transition-all duration-200">
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-600">Password</label>
          <input id="registerPassword" type="password" name="password" required class="mt-1 w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-300 transition-all duration-200">
        </div>
        <button type="submit" class="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-2 rounded-lg transition-all duration-200">
          Daftar
        </button>
      </form>
    </div>

    <p class="mt-6 text-xs text-gray-400 text-center">
      © 2025 E-Posyandu Bina Cita
    </p>
  </div>

  <!-- Script -->
  <script>
    function showTab(tab) {
      document.getElementById('loginForm').classList.toggle('hidden', tab !== 'login');
      document.getElementById('registerForm').classList.toggle('hidden', tab !== 'register');
      document.getElementById('tabLogin').classList.toggle('active', tab === 'login');
      document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
    }

    // Validasi tambahan saat submit
    document.getElementById('formLogin').addEventListener('submit', function(e) {
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;
      if (!email.includes('@') || !email.includes('.')) {
        e.preventDefault();
        alert('Format email tidak valid.');
        return;
      }
      if (password.length < 4) {
        e.preventDefault();
        alert('Password minimal 4 karakter.');
      }
    });

    document.getElementById('formRegister').addEventListener('submit', function(e) {
      const email = document.getElementById('registerEmail').value;
      const password = document.getElementById('registerPassword').value;
      if (!email.includes('@') || !email.includes('.')) {
        e.preventDefault();
        alert('Format email tidak valid.');
        return;
      }
      if (password.length < 4) {
        e.preventDefault();
        alert('Password minimal 4 karakter.');
      }
    });

    // Tampilkan tab sesuai parameter URL
    window.addEventListener('DOMContentLoaded', () => {
      const params = new URLSearchParams(window.location.search);
      const success = params.get('success');
      const error = params.get('error');
      if ((success && success.includes('Pendaftaran')) || (error && error.toLowerCase().includes('daftar'))) {
        showTab('register');
      } else {
        showTab('login');
      }
    });
  </script>
</body>
</html>

