<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'koneksi.php';

$nama     = $_POST['nama'] ?? '';
$email    = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi awal
if (!$nama || !$email || !$password) {
    header("Location: index.php?error=Semua data wajib diisi.");
    exit;
}

// Default role: 'peserta'
$default_role = 'peserta';

// Cek email sudah digunakan?
$cek = $conn->prepare("SELECT id FROM users WHERE email = ?");
if (!$cek) {
    die("Query gagal (cek email): " . $conn->error);
}
$cek->bind_param("s", $email);
$cek->execute();
$cek->store_result();

if ($cek->num_rows > 0) {
    header("Location: index.php?error=Email sudah terdaftar.");
    exit;
}

// Ambil ID dari role 'peserta'
$stmtRole = $conn->prepare("SELECT id FROM roles WHERE role_name = ?");
if (!$stmtRole) {
    die("Query gagal (ambil role): " . $conn->error);
}
$stmtRole->bind_param("s", $default_role);
$stmtRole->execute();
$resultRole = $stmtRole->get_result();

if ($resultRole->num_rows === 0) {
    header("Location: index.php?error=Role 'peserta' tidak ditemukan. Cek tabel roles.");
    exit;
}

$roleData = $resultRole->fetch_assoc();
$role_id = $roleData['id'];

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Simpan ke tabel users
$stmtInsert = $conn->prepare("INSERT INTO users (nama, email, password, role_id) VALUES (?, ?, ?, ?)");
if (!$stmtInsert) {
    die("Query gagal (insert user): " . $conn->error);
}
$stmtInsert->bind_param("sssi", $nama, $email, $hashedPassword, $role_id);

if ($stmtInsert->execute()) {
    header("Location: index.php?success=Pendaftaran berhasil. Silakan login.");
} else {
    header("Location: index.php?error=Gagal menyimpan data.");
}
exit;
?>

