<?php
session_start();
include 'koneksi.php'; // Pastikan file koneksi.php sudah ada dan berfungsi dengan benar

// Cek role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login_pengguna.php"); // Atau ke halaman login utama Anda jika ada
    exit;
}

$success_message = "";
$error_message = "";

// Ambil data anak
$query_data_anak = "SELECT * FROM data_anak ORDER BY nama_anak ASC"; // Mengurutkan berdasarkan nama anak
$data = mysqli_query($conn, $query_data_anak);

// Cek status dari redirect (misal dari tambah/edit/hapus)
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'added') {
        $success_message = "Data anak berhasil ditambahkan!";
    } elseif ($_GET['status'] == 'updated') {
        $success_message = "Data anak berhasil diperbarui!";
    } elseif ($_GET['status'] == 'deleted') {
        $success_message = "Data anak berhasil dihapus!";
    } elseif ($_GET['status'] == 'error_delete') {
        $error_message = "Gagal menghapus data anak.";
    }
}

// Fungsi untuk format tanggal (jika diperlukan, misalnya untuk tgl_lahir)
function formatTanggalIndo($tanggal) {
    if (empty($tanggal) || $tanggal === '0000-00-00') {
        return '-';
    }
    $bulan = [
        '01' => 'Januari', '02' => 'Februari', '03' => 'Maret',
        '04' => 'April', '05' => 'Mei', '06' => 'Juni',
        '07' => 'Juli', '08' => 'Agustus', '09' => 'September',
        '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
    ];
    $pecah_tgl = explode('-', $tanggal);
    return $pecah_tgl[2] . ' ' . $bulan[$pecah_tgl[1]] . ' ' . $pecah_tgl[0];
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Data Anak - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        /* Responsive Table Styling for small screens */
        @media screen and (max-width: 768px) {
            table {
                border: 0;
            }
            table thead {
                display: none;
            }
            table tr {
                display: block;
                margin-bottom: 0.825em;
                border: 1px solid #e2e8f0; /* gray-200 */
                border-radius: 0.75rem; /* rounded-xl */
                background-color: #ffffff;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* shadow-md */
            }
            table td {
                display: block;
                text-align: right;
                font-size: 0.9rem; /* text-sm slightly larger */
                border-bottom: 1px dotted #cbd5e0; /* gray-300 */
                padding: 0.625rem 1rem; /* Adjusted padding */
                position: relative;
                padding-left: 50%; /* Space for the label */
            }
            table td::before {
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 45%;
                padding-left: 1rem;
                font-weight: 600; /* font-semibold */
                text-align: left;
                color: #4a5568; /* gray-700 */
            }
            table td:last-child {
                border-bottom: 0;
            }
            table td:nth-last-child(2) { /* Target the Alamat column before actions */
                white-space: normal; /* Allow text to wrap */
                overflow: visible;
                text-overflow: clip;
            }
            table td:last-child { /* Actions column */
                text-align: center;
                padding-top: 1rem;
                padding-bottom: 1rem;
            }
            table td:last-child::before {
                display: none; /* Hide label for actions column */
            }
        }

        /* Optional: Custom scrollbar for better aesthetics */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px; /* For horizontal scrollbar */
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb {
            background: #a7f3d0; /* green-200 */
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #6ee7b7; /* green-300 */
        }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 text-gray-800 min-h-screen">

    <header class="bg-white shadow-lg px-4 sm:px-6 py-3 sm:py-4 flex flex-col sm:flex-row justify-between items-center sticky top-0 z-10">
        <div class="flex items-center mb-3 sm:mb-0 text-center sm:text-left">
            <svg class="h-8 w-8 sm:h-10 sm:w-10 text-green-600 mr-2 sm:mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.195-1.269-.545-1.782l-2.617-3.664M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.195-1.269.545-1.782l2.617-3.664m0 0L9.433 10.9A4.004 4.004 0 0111 6h2c1.455 0 2.723.738 3.486 1.89l.437.755M14.5 9.5a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
            </svg>
            <h1 class="text-xl sm:text-2xl font-bold text-green-800">Manajemen Data Anak</h1>
        </div>
        <a href="indext_admin.php" class="bg-green-500 text-white px-4 py-2 sm:px-5 sm:py-2 rounded-full hover:bg-green-600 transition duration-300 ease-in-out transform hover:scale-105 flex items-center text-sm">
            <i class="fas fa-arrow-left mr-2"></i> Kembali ke Dashboard Admin
        </a>
    </header>

    <main class="p-4 md:p-8 max-w-7xl mx-auto">
        <p class="mb-6 sm:mb-8 text-base sm:text-lg text-gray-700 text-center">
            Kelola informasi lengkap mengenai anak-anak yang terdaftar di Posyandu Bina Cita.
        </p>

        <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-6 text-sm" role="alert">
                <strong class="font-bold mr-1">Error!</strong>
                <span class="block sm:inline"><?= htmlspecialchars($error_message) ?></span>
            </div>
        <?php elseif (!empty($success_message)): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md relative mb-6 text-sm" role="alert">
                <strong class="font-bold mr-1">Berhasil!</strong>
                <span class="block sm:inline"><?= htmlspecialchars($success_message) ?></span>
            </div>
        <?php endif; ?>

        <div class="flex justify-center sm:justify-start mb-6">
            <a href="tambah_data_admin.php" class="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-300 ease-in-out transform hover:scale-105 flex items-center text-sm sm:text-base">
                <i class="fas fa-user-plus mr-2"></i> Tambah Data Anak Baru
            </a>
        </div>

        <div class="overflow-x-auto bg-white rounded-xl shadow-2xl border border-green-200">
            <table class="min-w-full text-sm table-auto divide-y divide-gray-200">
                <thead class="bg-green-600 text-white">
                    <tr>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider rounded-tl-xl">No</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider">NIK</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider">Nama Anak</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider">Tgl. Lahir</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider">Nama Ibu</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider">Nama Ayah</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-left font-semibold uppercase tracking-wider">Alamat</th>
                        <th class="px-4 py-2 sm:px-6 sm:py-3 text-center font-semibold uppercase tracking-wider rounded-tr-xl">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if (mysqli_num_rows($data) > 0): ?>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($data)): ?>
                        <tr class="hover:bg-green-50 transition duration-150 ease-in-out">
                            <td class="px-4 py-3 sm:px-6 sm:py-4 whitespace-nowrap font-medium text-gray-900" data-label="No">
                                <?= $no++ ?>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 whitespace-nowrap text-gray-700" data-label="NIK">
                                <?= htmlspecialchars($row['nik_anak']) ?>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 whitespace-nowrap text-gray-700" data-label="Nama Anak">
                                <?= htmlspecialchars($row['nama_anak']) ?>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 whitespace-nowrap text-gray-700" data-label="Tgl. Lahir">
                                <?= formatTanggalIndo($row['tgl_lahir']) ?>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 whitespace-nowrap text-gray-700" data-label="Nama Ibu">
                                <?= htmlspecialchars($row['nama_ibu']) ?>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 whitespace-nowrap text-gray-700" data-label="Nama Ayah">
                                <?= htmlspecialchars($row['nama_ayah']) ?>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 text-gray-700" data-label="Alamat">
                                <span class="block max-w-xs overflow-hidden text-ellipsis md:whitespace-nowrap">
                                    <?= htmlspecialchars($row['alamat']) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3 sm:px-6 sm:py-4 text-center font-medium flex items-center justify-center space-x-3">
                                <a href="edit_data_anak_admin.php?id=<?= $row['id'] ?>" class="text-yellow-600 hover:text-yellow-800 transition duration-150 ease-in-out" title="Edit Data">
                                    <i class="fas fa-edit text-lg"></i>
                                </a>
                                <a href="hapus_data_anak.php?id=<?= $row['id'] ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data anak ini? Tindakan ini tidak dapat dibatalkan.');" class="text-red-600 hover:text-red-800 transition duration-150 ease-in-out" title="Hapus Data">
                                    <i class="fas fa-trash-alt text-lg"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="px-6 py-8 text-center text-gray-500 bg-green-50">
                                <div class="flex flex-col items-center justify-center">
                                    <i class="fas fa-info-circle text-4xl text-green-400 mb-4"></i>
                                    <p class="text-lg font-medium mb-2">Belum ada data anak yang terdaftar.</p>
                                    <p class="text-sm text-gray-400">Silakan tambahkan data baru untuk memulai.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer class="bg-white border-t border-green-200 py-4 sm:py-6 mt-10">
        <div class="text-center text-xs sm:text-sm text-gray-600">
            &copy; <?= date('Y') ?> Posyandu Bina Cita. Semua Hak Dilindungi.
        </div>
    </footer>

</body>
</html>