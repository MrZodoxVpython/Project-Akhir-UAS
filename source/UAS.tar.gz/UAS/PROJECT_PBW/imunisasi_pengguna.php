<?php
session_start();
include 'koneksi.php'; // Make sure this path is correct

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'pengguna') {
    header("Location: login_pengguna.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Ambil data imunisasi untuk semua anak milik pengguna yang sedang login
$query = "
    SELECT a.nik_anak, a.nama_anak, i.jenis_imunisasi, i.tanggal, i.keterangan
    FROM data_anak a
    JOIN imunisasi i ON a.id = i.anak_id
    WHERE a.user_id = '$user_id'
    ORDER BY i.tanggal DESC
";

$result = mysqli_query($conn, $query);

// Check for query errors
if (!$result) {
    die("Query Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Imunisasi Anak | Posyandu Bina Cita</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        /* Custom responsive table styles for smaller screens */
        @media screen and (max-width: 768px) {
            table {
                border: 0;
            }
            table thead {
                display: none;
            }
            table tr {
                display: block;
                margin-bottom: .625em;
                border: 1px solid #e2e8f0; /* green-200 */
                border-radius: 0.5rem; /* rounded-lg */
                background-color: #ffffff; /* bg-white */
                box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06); /* shadow-md */
            }
            table td {
                display: block;
                text-align: right;
                font-size: 0.875rem; /* text-sm */
                border-bottom: 1px dotted #cbd5e0; /* gray-300 */
                padding: 0.5rem 1rem;
                position: relative;
                padding-left: 50%; /* Space for the label */
            }
            table td::before {
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 45%;
                padding-left: 1rem;
                font-weight: 600; /* font-semibold */
                text-align: left;
                color: #4a5568; /* gray-700 */
            }
            table td:last-child {
                border-bottom: 0;
            }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen p-4 sm:p-6 text-gray-800">

    <div class="container mx-auto bg-white rounded-xl shadow-lg p-6 sm:p-8 md:p-10 my-8">
        <header class="flex flex-col sm:flex-row justify-between items-center mb-6 sm:mb-8 pb-4 border-b border-green-200">
            <h1 class="text-2xl sm:text-3xl font-extrabold text-green-800 mb-3 sm:mb-0 flex items-center">
                <i class="fas fa-syringe text-green-600 mr-3"></i> Riwayat Imunisasi Anak
            </h1>
            <a href="indext_coba.php" class="text-green-600 hover:text-green-700 font-medium transition duration-300 ease-in-out flex items-center">
                <i class="fas fa-arrow-left mr-2"></i> Kembali ke Beranda
            </a>
        </header>

        <div class="overflow-x-auto bg-white rounded-lg shadow-md border border-green-100">
            <table class="min-w-full text-sm text-left">
                <thead class="bg-green-600 text-white sticky top-0">
                    <tr>
                        <th class="px-4 py-3 sm:px-6 sm:py-3 text-base font-semibold rounded-tl-lg">NIK Anak</th>
                        <th class="px-4 py-3 sm:px-6 sm:py-3 text-base font-semibold">Nama Anak</th>
                        <th class="px-4 py-3 sm:px-6 sm:py-3 text-base font-semibold">Jenis Imunisasi</th>
                        <th class="px-4 py-3 sm:px-6 sm:py-3 text-base font-semibold">Tanggal</th>
                        <th class="px-4 py-3 sm:px-6 sm:py-3 text-base font-semibold rounded-tr-lg">Keterangan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-green-100">
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr class="hover:bg-green-50 transition duration-150 ease-in-out">
                                <td class="px-4 py-3 sm:px-6 sm:py-3" data-label="NIK Anak"><?= htmlspecialchars($row['nik_anak']) ?></td>
                                <td class="px-4 py-3 sm:px-6 sm:py-3" data-label="Nama Anak"><?= htmlspecialchars($row['nama_anak']) ?></td>
                                <td class="px-4 py-3 sm:px-6 sm:py-3" data-label="Jenis Imunisasi"><?= htmlspecialchars($row['jenis_imunisasi']) ?></td>
                                <td class="px-4 py-3 sm:px-6 sm:py-3" data-label="Tanggal"><?= htmlspecialchars($row['tanggal']) ?></td>
                                <td class="px-4 py-3 sm:px-6 sm:py-3" data-label="Keterangan"><?= htmlspecialchars($row['keterangan']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-gray-500 px-4 py-6 text-base">
                                <div class="flex flex-col items-center justify-center py-8">
                                    <i class="fas fa-info-circle text-4xl text-green-400 mb-4"></i>
                                    <p class="text-lg font-medium">Belum ada data imunisasi untuk anak Anda.</p>
                                    <p class="text-sm text-gray-400 mt-1">Silakan hubungi Posyandu untuk informasi lebih lanjut.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>