<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Edukasi Ibu - Posyandu Bina Cita</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0fdf4; /* Slightly lighter green background */
            color: #374151; /* Default text color for better readability */
        }
        /* Header Enhancements */
        header {
            background-color: #047857; /* A deeper emerald green */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        header .container {
            display: flex;
            justify-content: space-between; /* Space out title and button */
            align-items: center;
        }
        header h1 {
            font-size: 1.75rem; /* Default size for small screens */
            font-weight: 700;
            letter-spacing: -0.025em; /* Slightly tighter letter spacing */
        }
        @media (min-width: 768px) { /* md breakpoint */
            header h1 {
                font-size: 2.5rem; /* Larger heading on medium screens and up */
            }
        }
        header p {
            font-size: 0.875rem; /* Default size for small screens */
            opacity: 0.9;
        }
        @media (min-width: 768px) { /* md breakpoint */
            header p {
                font-size: 1rem; /* Larger on medium screens and up */
            }
        }

        /* Back to Home Button */
        .back-home-btn {
            background-color: #059669; /* Brighter emerald for the button */
            color: white;
            padding: 0.6rem 1.2rem; /* Adjusted padding for smaller screens */
            border-radius: 9999px; /* Fully rounded pill shape */
            font-weight: 600;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.2s ease;
            font-size: 0.875rem; /* Smaller text for button on mobile */
        }
        @media (min-width: 640px) { /* sm breakpoint */
            .back-home-btn {
                padding: 0.75rem 1.5rem;
                font-size: 1rem;
            }
        }
        .back-home-btn:hover {
            background-color: #047857; /* Darker emerald on hover */
            transform: translateY(-2px); /* Slight lift on hover */
        }

        /* Main Section Padding */
        main {
            padding-top: 2rem; /* Adjusted for smaller screens */
            padding-bottom: 2rem;
        }
        @media (min-width: 640px) { /* sm breakpoint */
            main {
                padding-top: 3rem;
                padding-bottom: 3rem;
            }
        }

        /* Article Card Enhancements */
        .article-card {
            display: flex;
            flex-direction: column;
            height: 100%;
            transition: transform 0.3s ease, box-shadow 0.3s ease; /* Smooth transition for hover effects */
            border-radius: 0.75rem; /* More pronounced rounded corners */
            overflow: hidden;
            background-color: #ffffff;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.08); /* Softer, less spread out shadow for default */
            border: 1px solid #d1fae5; /* Light green border */
        }
        @media (min-width: 768px) { /* md breakpoint */
             .article-card {
                box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1); /* Larger shadow on desktop */
             }
        }

        .article-card:hover {
            transform: translateY(-5px); /* Lift effect on hover */
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15); /* More prominent shadow on hover for default */
        }
        @media (min-width: 768px) { /* md breakpoint */
            .article-card:hover {
                box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2); /* Even more prominent shadow on desktop hover */
            }
        }

        .article-card img {
            flex-shrink: 0;
            width: 100%;
            height: 180px; /* Adjusted height for better mobile display */
            object-fit: cover;
            border-top-left-radius: 0.75rem; /* Apply border-radius to image corners */
            border-top-right-radius: 0.75rem;
        }
        @media (min-width: 640px) { /* sm breakpoint */
            .article-card img {
                height: 200px; /* Slightly taller images on larger screens */
            }
        }

        .article-card .p-4 {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 1rem; /* More padding inside cards for default */
        }
        @media (min-width: 640px) { /* sm breakpoint */
            .article-card .p-4 {
                padding: 1.5rem; /* More padding inside cards on larger screens */
            }
        }

        .article-card h2 {
            font-size: 1.125rem; /* Smaller title for mobile */
            font-weight: 600;
            color: #047857; /* Match header green */
            margin-bottom: 0.5rem;
        }
        @media (min-width: 640px) { /* sm breakpoint */
            .article-card h2 {
                font-size: 1.25rem; /* Slightly larger title on larger screens */
                margin-bottom: 0.75rem;
            }
        }

        .article-card p {
            font-size: 0.875rem; /* Smaller body text for mobile */
            line-height: 1.6;
            color: #4b5563; /* Darker gray for better readability */
            margin-bottom: 0.75rem; /* Space before the link */
        }
        @media (min-width: 640px) { /* sm breakpoint */
            .article-card p {
                font-size: 0.95rem; /* Slightly larger body text on larger screens */
                margin-bottom: 1rem;
            }
        }

        .article-card a {
            display: inline-block;
            margin-top: auto; /* Push link to the bottom */
            color: #059669; /* A brighter emerald green for links */
            font-weight: 600;
            text-decoration: none;
            transition: color 0.2s ease;
            font-size: 0.875rem; /* Smaller link text for mobile */
        }
        @media (min-width: 640px) { /* sm breakpoint */
            .article-card a {
                font-size: 1rem; /* Larger link text on larger screens */
            }
        }

        .article-card a:hover {
            text-decoration: underline;
            color: #047857; /* Darker green on hover */
        }

        /* Footer Enhancements */
        footer {
            background-color: #e0f2f7; /* Lighter, subtle blue-green for footer */
            padding: 1rem; /* Adjusted padding for mobile */
            border-top: 1px solid #d1d5db; /* Light border above footer */
            text-align: center; /* Centered footer text */
        }
        @media (min-width: 640px) { /* sm breakpoint */
            footer {
                padding: 1.5rem;
            }
        }
        footer p {
            color: #6b7280;
            font-size: 0.8rem; /* Smaller font for mobile footer */
        }
        @media (min-width: 640px) { /* sm breakpoint */
            footer p {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body class="bg-green-50">

    <header class="text-white py-4 sm:py-6 shadow">
        <div class="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between">
            <div class="text-center sm:text-left mb-3 sm:mb-0">
                <h1 class="font-bold">Edukasi Ibu - Posyandu Bina Cita</h1>
                <p class="text-sm">Artikel kesehatan dan tumbuh kembang anak</p>
            </div>
            <a href="indext_coba.php" class="back-home-btn flex items-center justify-center">
                <i class="fas fa-home mr-2"></i> Kembali ke Halaman Utama
            </a>
        </div>
    </header>

    <main class="container mx-auto px-4 py-6 sm:py-8">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            <div class="article-card">
                <img src="https://imgur.com/PNydUvi.jpg" alt="Pentingnya ASI Eksklusif" class="object-cover">
                <div class="p-4">
                    <h2 class="font-bold">Pentingnya ASI Eksklusif</h2>
                    <p class="text-gray-700">ASI eksklusif sangat penting untuk meningkatkan imun dan perkembangan bayi secara optimal.</p>
                    <a href="https://upk.kemkes.go.id/new/ketahui-manfaat-asi-eksklusif-bagi-bayi-dan-ibu" target="_blank" rel="noopener noreferrer">
                        Baca Selengkapnya <i class="fas fa-external-link-alt ml-1 text-xs"></i>
                    </a>
                </div>
            </div>

            <div class="article-card">
                <img src="https://imgur.com/lZWI2Sm.jpg" alt="Gizi Anak" class="object-cover">
                <div class="p-4">
                    <h2 class="font-bold">Gizi Seimbang untuk Balita</h2>
                    <p class="text-gray-700">Penuhi kebutuhan gizi harian anak agar tumbuh sehat dan aktif sejak usia dini.</p>
                    <a href="https://ayosehat.kemkes.go.id/list-perangkat-ajar/makan-gizi-seimbang" target="_blank" rel="noopener noreferrer">
                        Baca Selengkapnya <i class="fas fa-external-link-alt ml-1 text-xs"></i>
                    </a>
                </div>
            </div>

            <div class="article-card">
                <img src="https://imgur.com/L1Hk8i8.jpg" alt="Imunisasi" class="object-cover">
                <div class="p-4">
                    <h2 class="font-bold">Imunisasi Lengkap untuk Perlindungan Optimal</h2>
                    <p class="text-gray-700">Kenali jadwal imunisasi lengkap dan manfaatnya untuk mencegah berbagai penyakit.</p>
                    <a href="https://primaku.com/berita/momdad--yuk-kenali-jenis-posyandu-beserta-manfaatnya-" target="_blank" rel="noopener noreferrer">
                        Baca Selengkapnya <i class="fas fa-external-link-alt ml-1 text-xs"></i>
                    </a>
                </div>
            </div>

            <div class="article-card">
                <img src="https://imgur.com/P7b0GKS.jpg" alt="Pola Asuh" class="object-cover">
                <div class="p-4">
                    <h2 class="font-bold">Pola Asuh Positif</h2>
                    <p class="text-gray-700">Pola asuh yang hangat dan tegas akan membantu anak tumbuh percaya diri dan mandiri.</p>
                    <a href="https://hellosehat.com/parenting/anak-6-sampai-9-tahun/perkembangan-anak/pengasuhan-positif-parenting/" target="_blank" rel="noopener noreferrer">
                        Baca Selengkapnya <i class="fas fa-external-link-alt ml-1 text-xs"></i>
                    </a>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2025 Posyandu Bina Cita. Semua Hak Dilindungi.</p>
    </footer>

</body>
</html>