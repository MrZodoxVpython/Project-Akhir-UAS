<?php
// ==== edit_imunisasi.php ====
session_start();
include 'koneksi.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Ambil ID dari parameter GET
if (!isset($_GET['id'])) {
    die("ID tidak ditemukan.");
}
$id = $_GET['id'];

// Ambil data imunisasi berdasarkan ID
$query = mysqli_query($conn, "SELECT * FROM imunisasi WHERE id = '$id'");
$data = mysqli_fetch_assoc($query);
if (!$data) {
    die("Data tidak ditemukan.");
}

// Ambil data anak untuk dropdown
$anak_result = mysqli_query($conn, "SELECT id, nik_anak, nama_anak FROM data_anak ORDER BY nama_anak ASC");

// Proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $anak_id        = $_POST['anak_id'];
    $jenis          = $_POST['jenis_imunisasi'];
    $tgl            = $_POST['tanggal'];
    $berat_badan    = $_POST['berat_badan'];
    $tinggi_badan   = $_POST['tinggi_badan'];
    $diagnosa       = $_POST['diagnosa'];
    $ket            = $_POST['keterangan'];

    // Using prepared statement for update
    $stmt = mysqli_prepare($conn, "UPDATE imunisasi SET anak_id=?, jenis_imunisasi=?, tanggal=?, berat_badan=?, tinggi_badan=?, diagnosa=?, keterangan=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, "issddssi", $anak_id, $jenis, $tgl, $berat_badan, $tinggi_badan, $diagnosa, $ket, $id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: imunisasi_pengguna.php?status=updated");
    } else {
        // Handle error, e.g., show a message or log it
        // For simplicity, we'll redirect back with an error status
        header("Location: imunisasi_pengguna.php?status=error_update");
    }
    mysqli_stmt_close($stmt);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Imunisasi</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0fdf4; /* Light green background */
        }
        /* Custom styles for form elements for better appearance */
        input[type="text"],
        input[type="date"],
        input[type="number"],
        select,
        textarea {
            /* Removed @apply here and explicitly set classes below for better control over the box-sizing */
            box-sizing: border-box; /* Crucial for preventing overflow */
            width: 100%; /* Ensure they take full width of their parent column */
            padding: 0.5rem 0.75rem; /* py-2 px-3 */
            border: 1px solid #d1d5db; /* border-gray-300 */
            border-radius: 0.375rem; /* rounded-md */
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05); /* shadow-sm */
            font-size: 0.875rem; /* sm:text-sm */
            line-height: 1.25rem;
            color: #1f2937; /* text-gray-900 */
        }

        /* Focus styles */
        input[type="text"]:focus,
        input[type="date"]:focus,
        input[type="number"]:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #34d399; /* green-500 */
            box-shadow: 0 0 0 1px #34d399; /* focus:ring-green-500 */
        }


        /* Style for required labels */
        label.required::after {
            content: '*';
            color: #ef4444; /* Red-500 */
            margin-left: 0.25rem;
        }

        /* Specific fix for number inputs to ensure no overflow from spin buttons */
        input[type="number"] {
            -moz-appearance: textfield; /* Firefox */
        }
        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-green-50 to-emerald-100 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-md sm:max-w-lg lg:max-w-xl border border-green-200 animate-fade-in">
        <h2 class="text-2xl sm:text-3xl font-extrabold text-green-800 mb-6 text-center tracking-tight">Edit Data Imunisasi</h2>
        <form method="POST">
            <div class="mb-5">
                <label for="anak_id" class="block text-sm font-medium text-gray-700 mb-1 required">Pilih Anak:</label>
                <div class="relative">
                    <select name="anak_id" id="anak_id" required class="w-full appearance-none pr-10">
                        <?php
                        // Reset pointer for anak_result if needed, though typically on a fresh page load it's fine
                        mysqli_data_seek($anak_result, 0); // Ensure cursor is at the beginning if this script was included
                        while ($anak = mysqli_fetch_assoc($anak_result)):
                        ?>
                            <option value="<?= htmlspecialchars($anak['id']) ?>" <?= $anak['id'] == $data['anak_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($anak['nik_anak']) ?> - <?= htmlspecialchars($anak['nama_anak']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                        <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                    </div>
                </div>
            </div>

            <div class="mb-5">
                <label for="jenis_imunisasi" class="block text-sm font-medium text-gray-700 mb-1 required">Jenis Imunisasi:</label>
                <input type="text" name="jenis_imunisasi" id="jenis_imunisasi" value="<?= htmlspecialchars($data['jenis_imunisasi']) ?>" required placeholder="Contoh: BCG, DPT-HB-Hib 1" />
            </div>

            <div class="mb-5">
                <label for="tanggal" class="block text-sm font-medium text-gray-700 mb-1 required">Tanggal Imunisasi:</label>
                <input type="date" name="tanggal" id="tanggal" value="<?= htmlspecialchars($data['tanggal']) ?>" required />
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
                <div>
                    <label for="berat_badan" class="block text-sm font-medium text-gray-700 mb-1 required">Berat Badan (kg):</label>
                    <input type="number" step="0.01" name="berat_badan" id="berat_badan" value="<?= htmlspecialchars($data['berat_badan']) ?>" required placeholder="Contoh: 7.5" />
                </div>
                <div>
                    <label for="tinggi_badan" class="block text-sm font-medium text-gray-700 mb-1 required">Tinggi Badan (cm):</label>
                    <input type="number" step="0.01" name="tinggi_badan" id="tinggi_badan" value="<?= htmlspecialchars($data['tinggi_badan']) ?>" required placeholder="Contoh: 68.2" />
                </div>
            </div>

            <div class="mb-5">
                <label for="diagnosa" class="block text-sm font-medium text-gray-700 mb-1">Diagnosa (Opsional):</label>
                <input type="text" name="diagnosa" id="diagnosa" value="<?= htmlspecialchars($data['diagnosa']) ?>" placeholder="Contoh: Batuk ringan, Sehat" />
            </div>

            <div class="mb-6">
                <label for="keterangan" class="block text-sm font-medium text-gray-700 mb-1">Keterangan Tambahan (Opsional):</label>
                <textarea name="keterangan" id="keterangan" rows="3" placeholder="Tambahkan catatan penting lainnya..."><?= htmlspecialchars($data['keterangan']) ?></textarea>
            </div>

            <div class="flex flex-col sm:flex-row justify-between items-center gap-3 mt-6">
                <button type="submit" class="w-full sm:w-auto bg-green-600 text-white px-8 py-2.5 rounded-lg font-semibold hover:bg-green-700 transition duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center shadow-md">
                    <i class="fas fa-save mr-2"></i> Update Data
                </button>
                <a href="imunisasi_pengguna.php" class="w-full sm:w-auto text-center text-sm font-medium text-gray-600 hover:text-gray-800 hover:underline transition duration-300 ease-in-out py-2 flex items-center justify-center">
                    <i class="fas fa-arrow-left mr-2"></i> Kembali ke Daftar Imunisasi
                </a>
            </div>
        </form>
    </div>
</body>
</html>